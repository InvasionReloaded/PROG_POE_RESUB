# AgriEnergyConnect

AgriEnergyConnect is a web application designed to help farmers manage their products and employees to oversee farmer profiles and product listings.

## Features

### User Roles
1.  **Farmer**
    *   Secure Login.
    *   Add new products (Name, Category, Production Date).
    *   View list of their own products.

2.  **Employee**
    *   Secure Login.
    *   Add new farmer profiles.
    *   View all products from all farmers.
    *   Filter products by Category, Date Range, and Specific Farmer.

### Technology Stack
*   **Framework**: ASP.NET Core MVC (.NET 8.0)
*   **Database**: SQLite (Entity Framework Core)
*   **Authentication**: ASP.NET Core Identity
*   **Frontend**: Bootstrap 5, Razor Views

## Prerequisites

*   [.NET 8.0 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) must be installed on your machine.
*   Visual Studio 2022 (Recommended) or Visual Studio Code.

## How to Build and Run

1.  **Install Prerequisites**: Ensure you have the .NET 8.0 SDK installed.
2.  **Navigate to Project Directory**:
    Open your terminal or command prompt and navigate to the `AgriEnergyConnect` folder.
    ```bash
    cd AgriEnergyConnect
    ```
3.  **Restore Dependencies**:
    ```bash
    dotnet restore
    ```
4.  **Run the Application**:
    ```bash
    dotnet run
    ```
    The application will start and listen on `http://localhost:5000` (or similar, check the output).
5.  **Database Setup**:
    The application is configured to use a local SQLite database (`app.db`). 
    On the first run, the database will be automatically created and seeded with sample data.

## Login Credentials (Sample Data)

The system comes pre-populated with the following users for testing:

*   **Employee**
    *   Email: `employee@agri.com`
    *   Password: `Password123!`
*   **Farmer**
    *   Email: `farmer@agri.com`
    *   Password: `Password123!`

## Project Structure

*   **Controllers**: Handles the request logic (Account, Farmers, Products).
*   **Models**: Defines the data structures (Farmer, Product).
*   **Views**: The UI pages (Razor .cshtml files).
*   **Data**: Database context and seeding logic.
*   **wwwroot**: Static files (CSS, JS).

## Development Notes

*   **Data Validation**: All forms include server-side validation.
*   **Security**: Pages are protected using `[Authorize]` attributes to ensure only authenticated users with the correct roles can access sensitive features.
