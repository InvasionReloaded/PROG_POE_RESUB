using AgriEnergyConnect.Models;
using Microsoft.AspNetCore.Identity;

namespace AgriEnergyConnect.Data
{
    public static class DbInitializer
    {
        public static async Task Initialize(IServiceProvider serviceProvider, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            // Ensure roles exist
            string[] roleNames = { "Employee", "Farmer" };
            foreach (var roleName in roleNames)
            {
                if (!await roleManager.RoleExistsAsync(roleName))
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            // Create a default Employee user
            var employeeEmail = "employee@agri.com";
            var employeeUser = await userManager.FindByEmailAsync(employeeEmail);
            if (employeeUser == null)
            {
                employeeUser = new IdentityUser { UserName = employeeEmail, Email = employeeEmail, EmailConfirmed = true };
                var result = await userManager.CreateAsync(employeeUser, "Password123!");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(employeeUser, "Employee");
                }
            }

            // Create a default Farmer user
            var farmerEmail = "farmer@agri.com";
            var farmerUser = await userManager.FindByEmailAsync(farmerEmail);
            if (farmerUser == null)
            {
                farmerUser = new IdentityUser { UserName = farmerEmail, Email = farmerEmail, EmailConfirmed = true };
                var result = await userManager.CreateAsync(farmerUser, "Password123!");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(farmerUser, "Farmer");
                }
            }

            // Seed Data Context
            var context = serviceProvider.GetRequiredService<ApplicationDbContext>();
            context.Database.EnsureCreated();

            if (!context.Farmers.Any())
            {
                var farmer1 = new Farmer
                {
                    Name = "John Doe",
                    Email = farmerEmail,
                    ContactNumber = "1234567890",
                    Address = "123 Farm Lane",
                    UserId = farmerUser?.Id 
                };
                
                var farmer2 = new Farmer
                {
                    Name = "Jane Smith",
                    Email = "jane@farm.com",
                    ContactNumber = "0987654321",
                    Address = "456 Crop Circle",
                    // No login for this one yet, just a profile added by employee potentially
                };

                context.Farmers.AddRange(farmer1, farmer2);
                context.SaveChanges();

                context.Products.AddRange(
                    new Product { Name = "Apples", Category = "Fruit", ProductionDate = DateTime.Now.AddDays(-10), FarmerId = farmer1.Id },
                    new Product { Name = "Wheat", Category = "Grain", ProductionDate = DateTime.Now.AddDays(-5), FarmerId = farmer1.Id },
                    new Product { Name = "Corn", Category = "Vegetable", ProductionDate = DateTime.Now.AddDays(-2), FarmerId = farmer2.Id }
                );
                context.SaveChanges();
            }
        }
    }
}
