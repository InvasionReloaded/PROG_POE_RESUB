using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AgriEnergyConnect.Data;
using AgriEnergyConnect.Models;
using System.Security.Claims;

namespace AgriEnergyConnect.Controllers
{
    [Authorize]
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public ProductsController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Products
        public async Task<IActionResult> Index(string category, DateTime? startDate, DateTime? endDate, int? farmerId)
        {
            var productsQuery = _context.Products.Include(p => p.Farmer).AsQueryable();

            if (User.IsInRole("Farmer"))
            {
                var userId = _userManager.GetUserId(User);
                var farmer = await _context.Farmers.FirstOrDefaultAsync(f => f.UserId == userId);
                if (farmer != null)
                {
                    productsQuery = productsQuery.Where(p => p.FarmerId == farmer.Id);
                }
                else
                {
                    // If user is a farmer role but has no farmer profile, show nothing or error
                    productsQuery = productsQuery.Where(p => false);
                }
            }
            else if (User.IsInRole("Employee"))
            {
                // Employee Filters
                if (!string.IsNullOrEmpty(category))
                {
                    productsQuery = productsQuery.Where(p => p.Category.Contains(category));
                }
                if (startDate.HasValue)
                {
                    productsQuery = productsQuery.Where(p => p.ProductionDate >= startDate.Value);
                }
                if (endDate.HasValue)
                {
                    productsQuery = productsQuery.Where(p => p.ProductionDate <= endDate.Value);
                }
                if (farmerId.HasValue)
                {
                    productsQuery = productsQuery.Where(p => p.FarmerId == farmerId.Value);
                }

                ViewData["Farmers"] = new SelectList(await _context.Farmers.ToListAsync(), "Id", "Name");
            }

            return View(await productsQuery.ToListAsync());
        }

        // GET: Products/Create
        [Authorize(Roles = "Farmer")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Farmer")]
        public async Task<IActionResult> Create([Bind("Id,Name,Category,ProductionDate")] Product product)
        {
            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(User);
                var farmer = await _context.Farmers.FirstOrDefaultAsync(f => f.UserId == userId);
                
                if (farmer != null)
                {
                    product.FarmerId = farmer.Id;
                    _context.Add(product);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError("", "Farmer profile not found for current user.");
            }
            return View(product);
        }
    }
}
